package swt.swl.topcard.controller;

import swt.swl.topcard.model.RequirementCardModel;

/**
 * 
 * @author swt-041649
 *
 */
public interface SearchRequirementCardController {

	void setData(RequirementCardModel model, RequirementCardController requirementCardControllerImpl);
}
