package swt.swl.topcard.logic.DAOs;

/**
 * 
 * @author swt-041649
 *
 */
public interface TeamDAO {

	/**
	 * 
	 * TODO: javadoc
	 * 
	 * @param value
	 * @return
	 */
	boolean hasTeam(String value);

	/**
	 * 
	 * TODO: javadoc
	 * 
	 * @param value
	 */
	void insertTeam(String value);

}
