package swt.swl.topcard.logic.entitiy;

/**
 * 
 * TODO: javadoc
 * 
 * @author -steve-
 *
 */
public interface OverallVoteScore {

	/**
	 * 
	 * TODO: javadoc
	 * 
	 * @return
	 */
	double getTotalAmount();

	/**
	 * 
	 * TODO: javadoc
	 * 
	 * @return
	 */
	int getYes();

	/**
	 * 
	 * TODO: javadoc
	 * 
	 * @return
	 */
	int getNo();

	/**
	 * 
	 * TODO: javadoc
	 * 
	 * @return
	 */
	int getDontKnow();

}
