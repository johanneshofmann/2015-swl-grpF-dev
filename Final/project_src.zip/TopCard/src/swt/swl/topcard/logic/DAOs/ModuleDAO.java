package swt.swl.topcard.logic.DAOs;

/**
 * 
 * @author swt-041649
 *
 */
public interface ModuleDAO {

	/**
	 * 
	 * TODO: javadoc
	 * 
	 * @param value
	 * @return
	 */
	boolean hasModule(String value);

	/**
	 * 
	 * TODO: javadoc
	 * 
	 * @param value
	 */
	void insertModule(String value);

}
