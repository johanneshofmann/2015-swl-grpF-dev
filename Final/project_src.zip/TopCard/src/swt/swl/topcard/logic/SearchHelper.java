package swt.swl.topcard.logic;

/**
 * 
 * 
 * @author swt-041649
 *
 */
public interface SearchHelper {

}
