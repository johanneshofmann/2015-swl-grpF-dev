package swt.swl.topcard.logic.entitiy;

/**
 * 
 * TODO: javadoc
 * 
 * @author swt-041649
 *
 */
public interface Team {

}
