package swt.swl.topcard.model.enums;

/**
 * 
 * TODO: javadoc
 * 
 * @author -steve-
 *
 */
public enum FrozenValue {
	ALL, YES, NO
}
