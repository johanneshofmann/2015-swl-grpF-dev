package swt.swl.topcard.model.enums;

/**
 * 
 * TODO: javadoc
 * 
 * @author -steve-
 *
 */
public enum SearchOperator {
	ALL, LESS, EQUAL, GREATER
}
