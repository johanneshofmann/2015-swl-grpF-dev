package swt.swl.topcard.model;

/**
 * 
 * TODO: javadoc
 * 
 * @author -steve-
 *
 */
public interface _Model {

}
