package swt.swl.topcard.controller;

import static org.junit.Assert.fail;

import org.junit.Test;

public class TestLoginWindowController {
	@Test
	public void alertAfterCloseWindow() {
		fail("Exception not thrown");

	}
}
