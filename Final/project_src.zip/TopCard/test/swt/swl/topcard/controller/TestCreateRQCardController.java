package swt.swl.topcard.controller;
//
//import static org.mockito.Mockito.mock;
//
//import org.junit.Test;
//
//import javafx.scene.control.Alert;
//import javafx.scene.control.Alert.AlertType;

public class TestCreateRQCardController {

//	private RequirementCardController mainController;
//
//	public TestCreateRQCardController() {
//		mainController = mock(RequirementCardController.class);
//	}
//
//	@Test
//	public void alertAfterCloseWindow() {
//		Alert al = new Alert(AlertType.CONFIRMATION, "");
//		// assertEquals(al, CreateRQCardController.closeWindow(ActionEvent
//		// event);
//	}
}
