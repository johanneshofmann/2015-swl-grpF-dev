package swt.swl.topcard.model.enums;

public enum SearchOperator {
	ALL, LESS, EQUAL, GREATER
}
