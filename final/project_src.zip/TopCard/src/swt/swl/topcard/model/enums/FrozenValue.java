package swt.swl.topcard.model.enums;

public enum FrozenValue {
	ALL, YES, NO
}
