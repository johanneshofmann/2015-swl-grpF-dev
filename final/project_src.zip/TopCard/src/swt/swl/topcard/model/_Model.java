package swt.swl.topcard.model;

/**
 * 
 * Model interface for all Models of the MVC
 * 
 * @author -steve-
 *
 */
public interface _Model {

}
