package swt.swl.topcard.controller;

/**
 * 
 * @author swt-041649
 *
 */
public interface ShowDiagramController {

	void setMainController(RequirementCardController requirementCardControllerImpl);

	void setData(RequirementCardController requirementCardController, String userName);
}
