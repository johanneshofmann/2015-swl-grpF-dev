package swt.swl.topcard.logic.entitiy;

/**
 * 
 * A simple module-entity.
 * 
 * @author swt-041649
 *
 */
public interface Module {

}
