package swt.swl.topcard.logic.entitiy;

/**
 * Interface for the Team-Entity
 * 
 * @author swt-041649
 *
 */
public interface Team {

}
