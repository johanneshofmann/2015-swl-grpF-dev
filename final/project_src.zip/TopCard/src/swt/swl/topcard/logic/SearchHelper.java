package swt.swl.topcard.logic;

/**
 * The Search Helper is a central Object in TopCard application. It is
 * responsible for most parts of the SEARCH-functionallity.
 * 
 * 
 * @author swt-041649
 *
 */
public interface SearchHelper {

}
